package com.novaos.launcher;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(7,21,38));
        getWindow().setNavigationBarColor(Color.rgb(7,21,38));
        setContentView(new NovaHomeView());
    }

    class NovaHomeView extends View {
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        final ArrayList<ResolveInfo> apps = new ArrayList<>();
        float downX, downY;
        long downAt;
        boolean wave;

        NovaHomeView() {
            super(MainActivity.this);
            Intent intent = new Intent(Intent.ACTION_MAIN, null);
            intent.addCategory(Intent.CATEGORY_LAUNCHER);
            List<ResolveInfo> found = getPackageManager().queryIntentActivities(intent, 0);
            Collections.sort(found, (a,b) -> String.valueOf(a.loadLabel(getPackageManager())).compareToIgnoreCase(String.valueOf(b.loadLabel(getPackageManager()))));
            for (ResolveInfo r : found) if (!r.activityInfo.packageName.equals(getPackageName())) apps.add(r);
        }

        void drawText(Canvas c, String s, float x, float y, float size, int color, Typeface face) {
            p.setShader(null); p.setStyle(Paint.Style.FILL); p.setColor(color); p.setTextSize(size); p.setTypeface(face); p.setTextAlign(Paint.Align.CENTER); c.drawText(s,x,y,p);
        }
        void glass(Canvas c, float l, float t, float r, float b, float radius, int alpha) {
            p.setShader(new LinearGradient(l,t,r,b,new int[]{Color.argb(alpha,255,255,255),Color.argb(alpha/3,130,205,255),Color.argb(alpha/5,255,255,255)},null,Shader.TileMode.CLAMP));
            p.setStyle(Paint.Style.FILL); c.drawRoundRect(l,t,r,b,radius,radius,p); p.setShader(null);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1.4f); p.setColor(Color.argb(150,210,239,255)); c.drawRoundRect(l,t,r,b,radius,radius,p); p.setStyle(Paint.Style.FILL);
        }
        @Override protected void onDraw(Canvas c) {
            super.onDraw(c); float w=getWidth(), h=getHeight();
            p.setShader(new LinearGradient(0,0,w,h,new int[]{0xff071526,0xff12395b,0xff07111f},null,Shader.TileMode.CLAMP)); c.drawRect(0,0,w,h,p); p.setShader(null);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(40); p.setStrokeCap(Paint.Cap.ROUND);
            p.setShader(new LinearGradient(0,h*.18f,w,h*.72f,new int[]{0x006ecfff,0x556ecfff,0x006ecfff},null,Shader.TileMode.CLAMP));
            Path aurora=new Path(); aurora.moveTo(-40,h*.34f); aurora.cubicTo(w*.28f,h*.08f,w*.58f,h*.58f,w+50,h*.25f); c.drawPath(aurora,p); p.setShader(null); p.setStyle(Paint.Style.FILL);
            drawText(c,"N O V A",w/2,h*.105f,15,0xffb8e7ff,Typeface.create("sans-serif-medium",Typeface.BOLD));
            String time=new SimpleDateFormat("HH:mm",Locale.getDefault()).format(new Date());
            drawText(c,time,w/2,h*.245f,76,0xffeff8ff,Typeface.create("sans-serif-thin",Typeface.NORMAL));
            String date=new SimpleDateFormat("EEEE, d MMMM",Locale.getDefault()).format(new Date());
            drawText(c,date,w/2,h*.285f,15,0xffc3dced,Typeface.create("sans-serif",Typeface.NORMAL));
            float sy=h*.36f, ey=sy+56; glass(c,w*.08f,sy,w*.92f,ey,28,42);
            p.setColor(0xffd7edfa); p.setTextSize(15); p.setTextAlign(Paint.Align.LEFT); c.drawText("⌕   Поиск приложений",w*.08f+22,sy+35,p);
            float dockTop=h*.83f, dockBottom=h*.92f; glass(c,w*.07f,dockTop,w*.93f,dockBottom,30,58);
            int dockCount=Math.min(4,apps.size());
            for(int i=0;i<dockCount;i++) drawApp(c,apps.get(i),w*(.18f+i*.213f), (dockTop+dockBottom)/2, 22);
            int shown=Math.min(8,Math.max(0,apps.size()-dockCount));
            for(int i=0;i<shown;i++) { int col=i%4,row=i/4; float x=w*(.125f+col*.25f), y=h*.49f+row*h*.115f; drawApp(c,apps.get(dockCount+i),x,y,22); }
            if(wave && System.currentTimeMillis()-downAt<420) { float t=(System.currentTimeMillis()-downAt)/420f; p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2.5f*(1-t)); p.setColor(Color.argb((int)(180*(1-t)),130,220,255)); c.drawCircle(downX,downY,t*145,p); p.setStyle(Paint.Style.FILL); postInvalidateDelayed(16); } else wave=false;
            drawText(c,"NOVA OS  •  1.0",w/2,h*.965f,10,0x99ccecff,Typeface.create("sans-serif",Typeface.NORMAL));
        }
        void drawApp(Canvas c, ResolveInfo r, float x, float y, float size) {
            android.graphics.drawable.Drawable d=r.loadIcon(getPackageManager()); d.setBounds((int)(x-size),(int)(y-size),(int)(x+size),(int)(y+size)); d.draw(c);
            p.setStyle(Paint.Style.FILL); p.setColor(0xffedf8ff); p.setTextSize(10); p.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL)); p.setTextAlign(Paint.Align.CENTER);
            String label=String.valueOf(r.loadLabel(getPackageManager())); if(label.length()>12) label=label.substring(0,11)+"…"; c.drawText(label,x,y+size+15,p);
        }
        void launch(ResolveInfo r) { Intent i=new Intent(Intent.ACTION_MAIN); i.addCategory(Intent.CATEGORY_LAUNCHER); i.setClassName(r.activityInfo.packageName,r.activityInfo.name); try { startActivity(i); } catch(Exception ignored) {} }
        void showDrawer() { ArrayList<String> names=new ArrayList<>(); for(ResolveInfo r:apps) names.add(String.valueOf(r.loadLabel(getPackageManager()))); new android.app.AlertDialog.Builder(MainActivity.this).setTitle("Все приложения").setItems(names.toArray(new String[0]),(d,n)->launch(apps.get(n))).setNegativeButton("Закрыть",null).show(); }
        @Override public boolean onTouchEvent(MotionEvent e) {
            if(e.getAction()==MotionEvent.ACTION_DOWN) { downX=e.getX(); downY=e.getY(); downAt=System.currentTimeMillis(); wave=true; invalidate(); return true; }
            if(e.getAction()==MotionEvent.ACTION_UP) { float w=getWidth(),h=getHeight(),x=e.getX(),y=e.getY(); int dockCount=Math.min(4,apps.size());
                if(y>h*.83f && y<h*.94f) { int idx=Math.round((x/w-.18f)/.213f); if(idx>=0 && idx<dockCount) launch(apps.get(idx)); }
                else if(y>h*.46f && y<h*.78f) { int col=Math.min(3,Math.max(0,(int)(x/(w/4)))); int row=Math.max(0,Math.round((y-h*.49f)/(h*.115f))); int idx=dockCount+row*4+col; if(idx>=dockCount && idx<apps.size() && idx<dockCount+8) launch(apps.get(idx)); }
                else if(y>h*.34f && y<h*.43f) showDrawer(); invalidate(); return true; }
            return true;
        }
    }
}
